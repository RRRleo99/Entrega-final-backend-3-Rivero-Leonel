# 🐾 Proyecto AdoptMe - Backend III: Final

¡Hola Este es mi proyecto final para el curso de Backend III. Se trata de un sistema de gestión para una plataforma de adopción de mascotas, con foco en **documentación, testing y contenedores**.

---

##  Cómo empezar?

### 1. Instalación
Clona el repositorio e instala las dependencias:
```bash
npm install