import { expect } from 'chai';
import supertest from 'supertest';

const requester = supertest('http://localhost:8080');

describe('Test de Adopciones', () => {
    it('GET /api/adoptions debe devolver status 200', async () => {
        const { status } = await requester.get('/api/adoptions');
        expect(status).to.equal(200);
    });
});